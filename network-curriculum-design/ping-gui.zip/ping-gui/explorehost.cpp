#include "mainwindow.h"

#include <QDebug>
#include <QMutex>

#include <stdio.h>
#include <sys/types.h>
#include <sys/socket.h>
#include <netinet/in.h>
#include <netinet/ip.h>
#include <netinet/ip_icmp.h>
#include <arpa/inet.h>
#include <unistd.h>
#include <netdb.h>
#include <iostream>

int ExploreHost::pid;                       //进程号
char ExploreHost::send_buffer[BUFFER_SIZE]; //发送缓冲区，大小为1K
char ExploreHost::recv_buffer[BUFFER_SIZE]; //接受缓冲区，大小为1K
QString ExploreHost::str_addr;

ExploreHost::ExploreHost()                  //构造函数
{

}

void ExploreHost::run()                     //次线程
{
    emit debug_Signal(QString("Program starts to explore the host(%1). ").arg(str_addr)); //探测程序开始执行
    qDebug()<<"Thread ID:"<<QThread::currentThreadId(); //次线程的线程号
int sockICMP;                                           //套接字描述符
    char *ip_addr;                                      //点分十进制IP地址
    int size = 1024;                                    //缓冲区，大小1K
    struct sockaddr_in dest_addr;                       //所要探测的主机IP
    struct protoent *protocol;                          //协议
    qDebug()<<str_addr;
    QByteArray temp = str_addr.toUtf8();                //将QString转化为char数组
    ip_addr = temp.data();      
    bool flag = true;                                   //标志申请套接字和设置的协议是否正确
    if((protocol = getprotobyname("icmp") ) == NULL)
    {
        emit debug_Signal("Protocol error");
        //qDebug()<<"Protocol error ";
        flag = false;
    }
    if((sockICMP = socket(AF_INET,SOCK_RAW,IPPROTO_ICMP))<0) //向系统申请一个套接字，需要有root权限
    {
        emit debug_Signal("Socket error, Are you root? ");
        //qDebug()<<"socket error";
        flag = false;
    }

    setuid(getuid());   //为了安全起见，线程申请了套接字后就回收root权限，设置成当前用户权限
    if(flag)        //没有出现错误程序才继续向下进行
    {
        setsockopt(sockICMP, SOL_SOCKET, SO_RCVBUF, &size, sizeof(size));           //设置套接字接收缓冲区为1k
        bzero(&dest_addr,sizeof(dest_addr)); //把主机IP全部位置零
        dest_addr.sin_family = AF_INET;      //代表TCP/IP协议族

        if(!inet_pton(AF_INET, ip_addr, &dest_addr.sin_addr)) //点分十进制IP地址ip_addr转为socket_in结构的二进制IP地址sin_addr
            emit debug_Signal("Address error");
        else
        {
            pid = getpid();                 //获得当前进程的进程号                 
            send_ip(sockICMP, &dest_addr);  //发送IP包
            recv_ip(sockICMP, &dest_addr);  //接收IP包
            emit debug_Signal("Exploration completed! \r\n");
        }       
    }
}

void ExploreHost::send_ip(int sockICMP, struct sockaddr_in *dest_addr) //发送IP包的函数
{
    if(code_icmphdr() != 0)                     //设置ICMP报文头部
        qDebug()<<"code ICMP header error";
    int icmp_len = sizeof(struct icmp);         //获得ICMP报文长度
    //以面向无连接的方式发送ICMP报文，封装到IP包中才发送出去
    if(sendto(sockICMP, send_buffer, icmp_len, 0, (struct sockaddr *)dest_addr, sizeof(struct sockaddr_in)) < 0)
        qDebug()<<"sendto error";
    else emit debug_Signal("Send successfully! ");
}

void ExploreHost::recv_ip(int sockICMP, struct sockaddr_in *from_addr) //接受IP包的函数
{
    struct timeval time_out;
    time_out.tv_sec=5;
    time_out.tv_usec=0;
    setsockopt(sockICMP, SOL_SOCKET, SO_RCVTIMEO, &time_out, sizeof(time_out)); //设置超时时间5秒
    int ip_recv;        //设置成接收到IP包长度
    socklen_t fromlen;  
    if((ip_recv = recvfrom(sockICMP, recv_buffer, sizeof(recv_buffer),
                            0, (struct sockaddr *)from_addr, &fromlen)) < 0)
    {
        emit debug_Signal("Time out."); //超时
        //qDebug()<<"recvfrom error";
    }
    else if(decode_iphdr(recv_buffer, ip_recv) == -1) //IP包头部解码错误
        qDebug()<<"recvfrom decode error"; 
    else
    {
        struct in_addr addr1, addr2;          //IP地址
        memcpy(&addr1, recv_buffer + 12, 4);  //复制IP地址
        memcpy(&addr2, recv_buffer + 16, 4);  //复制IP地址
        
        QString sip = QString::fromLocal8Bit(inet_ntoa(addr1)); //二进制地址转点分十进制
        QString dip = QString::fromLocal8Bit(inet_ntoa(addr2)); //二进制地址转点分十进制
        emit debug_Signal("Source IP: " + sip + " Dest IP: " + dip);
    }
}

int ExploreHost::code_icmphdr() //编辑ICMP报文头部
{
    struct icmp *icmphdr;       //声明一个ICMP结构
    icmphdr = (struct icmp*)send_buffer; //将ICMP报文指向发送区首地址
    icmphdr->icmp_type = ICMP_ECHO;      //请求回显类型
    icmphdr->icmp_code = 0;
    icmphdr->icmp_cksum = 0;             //检验和
    icmphdr->icmp_seq = 0;               //编号
    icmphdr->icmp_id = getpid();         //进程号
    int icmp_len = sizeof(struct icmp);  //ICMP报文长度
    icmphdr->icmp_cksum = icmp_chksum((unsigned short *)icmphdr, icmp_len); //计算检验和
    return 0;
}

int ExploreHost::decode_iphdr(char *buf, int len)
{
    int ip_len;
    struct icmp *icmp;          //声明ICMP报文
    struct ip * ip_pack;        //声明IP包
    ip_pack = (struct ip *)buf;  //设置IP包的地址为缓冲区首地址
    ip_len = ip_pack->ip_hl * 4; //求IP包长度,即长度标志乘4
    icmp = (struct icmp *)(buf + ip_len); //buf首地址加IP数据包头部后就是ICMP报文起始地址了
    len -=ip_len;               //ICMP报文长度
    if( len < 8)                //ICMP报文过短
    {
        qDebug()<<"ICMP packets's length is less than 8! \n";
        return -1;
    }

    if( (icmp->icmp_type == ICMP_ECHOREPLY) && (icmp->icmp_id == pid) ) //接收的ICMP类型为回显应答且进程相同
    {
        emit debug_Signal("The host is alive! ");                       //在线
        //qDebug()<<"The host is alive ";
    }
    else if( icmp->icmp_type == ICMP_DEST_UNREACH)                      //主机不可达
    {
        emit debug_Signal("The host is unreachable! ");
        //qDebug()<<"icmp_seq is out ";
        uint8_t iii;
        iii = icmp->icmp_code;
        qDebug()<<"icmp_code="<< QString::number(iii);

    }
    return 0;
}

unsigned short ExploreHost::icmp_chksum(unsigned short *addr,int len)
{
    int nleft = len;
    int nChksum = 0;
    unsigned short answer = 0;
    // 把ICMP报头二进制数据每2字节累加
    while(nleft > 1)
    {
        nChksum += *addr;
        nleft -= 2;
        addr++;
    }
    // 若ICMP报头为奇数个字节，会剩下最后一字节。把最后一个字节视为一个2字节数据的高字节，低字节为置零，继续累加
    if( nleft == 1)
    {
        *(unsigned char *)(&answer) = *(unsigned char *)addr;
        nChksum += answer;
    }
    nChksum = (nChksum>>16)+(nChksum&0xffff);
    nChksum += (nChksum>>16);
    answer = ~nChksum;
    return answer;
}

ExploreHost::~ExploreHost() //析构函数
{
    qDebug()<<tr("End");
}
