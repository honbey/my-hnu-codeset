/*---此程序需要在root权限下才能运行---*/
#include <stdio.h>
#include <string.h>
#include <stdlib.h>
#include <unistd.h>
#include <sys/types.h>
#include <sys/socket.h>
#include <netinet/in.h>
#include <netinet/ip_icmp.h>
#include <arpa/inet.h>

void send_icmp(int sockfd, struct sockaddr_in *dstaddr);//发送ICMP
void recv_icmp(int sockfd);//接受回复的ICMP

int main(int argc, char** argv)	//主函数
{
	if(argc != 2)		//如果参数个数错误，立即结束运行
	{
		printf("Usage: ./ICMP Host_IP\n");
		return -1;
	}

	int sockfd;			//定义套接字描述符
	struct sockaddr_in dstaddr;
	//创建一个新套接字，socket函数成功执行返回一个套接字描述符
	if((sockfd = socket(PF_INET,	//PF_INET/AF_INET表示TCP/IP协议族
						SOCK_RAW,	//SOCK_DGRAW(数据报服务类型)/SOCK_STREAM(数据流服务类型)
						IPPROTO_ICMP)) == -1)//IPPROTO_ICMP具体协议的协议号，此处为ICMP协议
	//返回的套接字描述符实际上是一个指向socket数据结构的指针
		printf("err: 创建socket出错！");

	bzero(&dstaddr, sizeof(dstaddr));
	dstaddr.sin_family = AF_INET;
	dstaddr.sin_port = htons(0);
	//将输入的点分十进制(argv[1])转化为二进制地址类型
	if(inet_pton(AF_INET, argv[1], &dstaddr.sin_addr) <= 0)		
		printf("err: 地址转换错误！\n");
	send_icmp(sockfd, &dstaddr);
	recv_icmp(sockfd);
	printf("\n");
	return 0;
}

void send_icmp(int sockfd, struct sockaddr_in *dstaddr) //发送ICMP
{
	char buf[100];
	size_t len = sizeof(struct icmp);
	struct icmp *icmp;
	bzero(buf, sizeof(buf));
	icmp = (struct icmp * )buf;
	icmp -> icmp_type = ICMP_ECHO;
	icmp -> icmp_code = 0;
	icmp -> icmp_id	= getpid();
	icmp -> icmp_seq = 1;
	//计算校验和,并将所得结果填入对应icmp报文区域中
	int len_ = sizeof(struct icmp);
	uint16_t *w = (uint16_t *) icmp;
	uint16_t answer = 0;
	uint32_t sum = 0;
	while(len_ > 1)
	{
		sum += *w++;
		len_ -= 2;
	}
	if(len_ == 1)
	{
		*(unsigned char * )(&answer) = *(unsigned char * )w;
		sum += answer;
	}
	sum = (sum >> 16) + (sum & 0xffff);
	sum += (sum >> 16);
	answer = ~sum;
	icmp -> icmp_cksum = answer;

	/*sendto函数用于在无连接的数据报socket方式下
	进行数据的发送，需指明目的机器的端点地址，
	正确执行返回实际发送的数据字节长度。*/
	//socklen_t dstlen = sizeof(struct sockaddr_in);
	if(sendto(sockfd,	//指明用来发送数据的套接字描述符
			  buf,		//指明一个存放应用程序要发送的数据的缓冲区
			  len,		//指明缓冲区的长度
			  0,		//指明调用执行的方式，一般设置为0
			  (struct sockaddr * )dstaddr, //一个指向数据结构sockaddr的指针
			  sizeof(struct sockaddr_in)) == -1)	//远端地址结构serv_addr的长度
		printf("err: sendto函数出错");
}

void recv_icmp(int sockfd) //接受回复的ICMP
{
	char buf[100];
	size_t n;
	struct ip *ip;
	struct icmp *icmp;
	while(1)
	{
		alarm(5); //超时，一般是主机不在线
		if((n = read(sockfd, buf, sizeof(buf))) == -1)	//read函数，将sockfd所指的缓冲区内的数据
			printf("err: read函数出错");
		ip = (struct ip * )buf;
		if(ip -> ip_p != IPPROTO_ICMP)
		{
			printf("err: 协议错误");
			exit(1);
		}
		icmp = (struct icmp *)(buf + sizeof(struct ip));
		if(icmp -> icmp_type == ICMP_ECHOREPLY)
		{
			if(icmp -> icmp_id != getpid()) //发送的ICMP包的id要和接受的ICMP包的id对应
			{
				printf("err: 不是此进程");
				exit(1);
			}
			else
			{
				printf("所探测的主机在线");
				break;
			}
		}
	}
}
