#ifndef MAINWINDOW_H
#define MAINWINDOW_H

#include <QMainWindow>

#include <QThread>
#include <QObject>
#include <QDateTime>
#include <QTimer>
#include <QMessageBox>
#include <QDebug>
#include <QFile>

#define BUFFER_SIZE 1024

class ExploreHost : public QThread //为QThread的子类
{
    Q_OBJECT

public:
    explicit ExploreHost();
    ~ExploreHost();
    void closeThread();

    //全局变量
    static int pid;
    static char send_buffer[BUFFER_SIZE];
    static char recv_buffer[BUFFER_SIZE];
    static QString str_addr;

signals:
    void debug_Signal(QString); //输出调试信息的信号函数

protected:
    virtual void run();         //次线程

private:
    void send_ip(int sockfd, struct sockaddr_in *dest_addr); //发送IP包

    void recv_ip(int sockfd, struct sockaddr_in *from_addr); //接收IP包

    int code_icmphdr(); //设置ICMP头部

    int decode_iphdr(char *buf, int nlen); //解码IP数据包头部

    unsigned short icmp_chksum(unsigned short *addr,int nLen); //计算校验和
};

namespace Ui {
class MainWindow;
}

class MainWindow : public QMainWindow
{
    Q_OBJECT

public:
    explicit MainWindow(QWidget *parent = 0);
    ~MainWindow();

private slots:
    void on_b_Start_clicked(); //开始按钮

    void on_b_Clear_clicked(); //清空按钮

    void on_b_Clear_singleC(); //single click

    void finish_Thread_Slot(); //次线程结束信号的槽函数

    void debug_Slot(QString);  //调试信息的槽函数

    void on_actionExit_triggered(); //退出

    void on_actionUser_Guideline_triggered();

    void on_actionAbout_triggered();

    void on_actionReport_Bug_triggered();

    void on_actionConnect_with_us_triggered();

    void on_actionShare_triggered();

private:
    Ui::MainWindow *ui;
    ExploreHost *icmp_explore; //声明线程
    QTimer* isDoubleClicked; //判断单双击的定时器
    int countClicked;
};

#endif // MAINWINDOW_H
