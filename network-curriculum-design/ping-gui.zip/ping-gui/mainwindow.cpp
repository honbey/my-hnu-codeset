#include "mainwindow.h"
#include "ui_mainwindow.h"

MainWindow::MainWindow(QWidget *parent) :
    QMainWindow(parent),
    ui(new Ui::MainWindow)
{
    ui->setupUi(this);
    //设置输入框格式和限制
    QIntValidator *limiteditIP1 = new QIntValidator(0, 255, ui->editIP_1);
    QIntValidator *limiteditIP2 = new QIntValidator(0, 255, ui->editIP_2);
    QIntValidator *limiteditIP3 = new QIntValidator(0, 255, ui->editIP_3);
    QIntValidator *limiteditIP4 = new QIntValidator(0, 255, ui->editIP_4);
    ui->editIP_1->setValidator(limiteditIP1);
    ui->editIP_2->setValidator(limiteditIP2);
    ui->editIP_3->setValidator(limiteditIP3);
    ui->editIP_4->setValidator(limiteditIP4);
    QDateTime time = QDateTime::currentDateTime();
    //设置信息框
    QString now = time.toString("yyyy-MM-dd hh:mm:ss");
    ui->textBrowser_Debug->setText(now + " : Program strats to run. ");
    ui->textBrowser_Debug->setVerticalScrollBarPolicy(Qt::ScrollBarAlwaysOff);
    ui->textBrowser_Debug->setHorizontalScrollBarPolicy(Qt::ScrollBarAlwaysOff);
    //log
    QString fileName = "../ICMP_V2/log.txt";
    QFile file(fileName);
    if (file.open(QIODevice::ReadWrite | QIODevice::Text))
    {
        QTextStream stream(&file);
        stream.seek(file.size());
        stream << "\r\n\r\n##############################\r\n" + now + " : Program run log. \r\n------------------------------\r\n";
        file.close();
    }
    //Is mouse click single or double
    countClicked = 0;
    isDoubleClicked = new QTimer(this);
    //次线程
    icmp_explore = new ExploreHost;
    //xinhao...
    connect(isDoubleClicked, SIGNAL(timeout()), this, SLOT(on_b_Clear_singleC()));
    connect(icmp_explore, SIGNAL(finished()), this, SLOT(finish_Thread_Slot()));
    connect(icmp_explore, SIGNAL(debug_Signal(QString)), this, SLOT(debug_Slot(QString)));
}

void MainWindow::debug_Slot(QString str)
{
    QDateTime time = QDateTime::currentDateTime();
    QString now = time.toString("yyyy-MM-dd hh:mm:ss.zzz");
    ui->textBrowser_Debug->append(now + " : " + str);
    //QString fileName = "/home/hub/log.txt";
    //log
    QString fileName = "../ICMP_V2/log.txt";
    QFile file(fileName);
    if (file.open(QIODevice::ReadWrite | QIODevice::Text))
    {
        QTextStream stream(&file);
        stream.seek(file.size());

        stream << now + " : " + str << "\r\n";
        file.close();
    }
}

void MainWindow::on_b_Start_clicked()
{
    if(icmp_explore->isRunning())
        ui->textBrowser_Debug->append("The ICMP exploration is running");
    else
    {
        QString str_addr = QString("%1.%2.%3.%4")
                .arg(ui->editIP_1->text().trimmed())
                .arg(ui->editIP_2->text().trimmed())
                .arg(ui->editIP_3->text().trimmed())
                .arg(ui->editIP_4->text().trimmed());
        icmp_explore->str_addr = str_addr;
        icmp_explore->start();
        qDebug()<<"Main Thread ID:"<<QThread::currentThreadId();
    }
}

void MainWindow::on_b_Clear_singleC() //
{
    countClicked = 0;
    isDoubleClicked->stop();

    ui->editIP_1->clear();
    ui->editIP_2->clear();
    ui->editIP_3->clear();
    ui->editIP_4->clear();
    ui->textBrowser_Debug->append("The input box have cleared! ");
}

void MainWindow::on_b_Clear_clicked()
{
    countClicked++;
    if(countClicked == 1)
        isDoubleClicked->start(300);

    if(countClicked == 2)
    {
        countClicked =0;
        isDoubleClicked->stop();

        ui->textBrowser_Debug->clear();
        ui->editIP_1->clear();
        ui->editIP_2->clear();
        ui->editIP_3->clear();
        ui->editIP_4->clear();
        ui->textBrowser_Debug->append("The input and information box have cleared! ");
    }
}

void MainWindow::finish_Thread_Slot()
{
    //ui->textBrowser_Debug->append(icmp_explore->str_info);
    qDebug()<<"finish";
}

void MainWindow::on_actionExit_triggered()
{
    close();
}

void MainWindow::on_actionUser_Guideline_triggered()
{
    QString str=QString("<h1>Please visit: <a href=\"http://120.79.74.191:5000/cnet\">http://120.79.74.191:5000/cnet</a></h1>");
    QLabel *lab = new QLabel(str);
    lab->setOpenExternalLinks(true);
    lab->setWindowTitle("User Guideline");
    lab->show();
}

void MainWindow::on_actionAbout_triggered()
{
    QMessageBox::information(0, tr("About"),
                             tr("ICMP V2.2 \nOnly use to Computer Network Curriculum Design!"),
                             QMessageBox::Yes);
}

void MainWindow::on_actionReport_Bug_triggered()
{
    QMessageBox::information(0, tr("Report Bug"),
                             tr("Please the BUG to hubzhang@qq.com. \nThanks!"),
                             QMessageBox::Yes);
}

void MainWindow::on_actionConnect_with_us_triggered()
{
    QMessageBox::information(0, tr("Connect with us"),
                             tr("Our E-mail address: hubzhang@qq.com. \nThanks!"),
                             QMessageBox::Yes);
}

void MainWindow::on_actionShare_triggered()
{
    QMessageBox::information(0, tr("Share"),
                             tr("Thanks,\nThanks!"),
                             QMessageBox::Yes);
}

MainWindow::~MainWindow()
{
    //icmp_explore->terminate();
    icmp_explore->wait(); //等待次线程结束才结束主线程
    delete ui;
}
