#include <stdio.h>
#include <string.h>
#include <sys/time.h>
#include "portscan.h"

int main(int argc, char *argv[]) {
    if (argc < 2 || argc > 5) {
        printf("error parameter\n");
        exit(1);
    }
    struct timeval begin, end;
    gettimeofday(&begin, NULL);
    int begin_port = atoi(argv[2]);
    int end_port   = atoi(argv[3]);
    int flag       = atoi(argv[4]);
    if ((begin_port > end_port) ||
	(begin_port < 1) || 
	(end_port   < 1) ||
	(begin_port > 65535) || 
	(end_port   > 65535)) {
	printf("Begin port bigger than end port! Set begin port to 1 and end with 1024.\n");
    	begin_port = 1;
	end_port = 1024;
    }
    if ((flag > 2) || (flag < 0)) {
    	printf("Scan type set to TCP connect().\n");
	flag = 1;
    }
    Scan(argv[1], begin_port, end_port, flag);
    gettimeofday(&end, NULL);
    double time = 1000000 * (end.tv_sec - begin.tv_sec) + end.tv_usec - begin.tv_usec;
    printf("Total times: %lf seconds\n", time/1000000);
    return 0;
}
