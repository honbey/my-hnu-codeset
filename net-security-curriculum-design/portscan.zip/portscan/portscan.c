#include "portscan.h"

static struct in_addr gDstIp;
static struct iphdr *gIphdr = NULL;
static struct tcphdr *gTcphdr = NULL;
static struct psdhdr *gPsdhdr;
static char gSourceIp[20] = { 0 };
static char gDatagram[4096] = { 0 };
static int gTotalPorts[65536] = { 0 };
static int gSourcePort = 65000;
static int gPorts;
static int gSockfd;
static int gFlag;

const char* cDnsIp = "114.114.114.114";

void InitDstIp(char *target) {
    if (inet_addr(target) != -1) {
        gDstIp.s_addr = inet_addr(target);
        printf("Remote host IP address is %s\n", target);
    } else {
        char *ip = GetHostByName(target);
        if (ip != NULL) {
            printf("Remote host IP address is %s \n", ip);
            // 获取目标主机的IP地址
            gDstIp.s_addr = inet_addr(GetHostByName(target));
        } else {
            perror("find host fails:");
            exit(1);
        }
    }
}
void InitPSDhdr(struct psdhdr *psdhdr_data){
    psdhdr_data->src_addr = inet_addr(gSourceIp);
    psdhdr_data->dst_addr = gDstIp.s_addr;
    psdhdr_data->placeholder = 0;
    psdhdr_data->protocol = IPPROTO_TCP;
    psdhdr_data->tcp_length = htons(TCPHDR_SIZE);
}
void InitIpHdr(struct iphdr *iphdr_data, char *datagram){
    iphdr_data->ihl = 5;
    iphdr_data->version = 4;
    iphdr_data->tos = 0;
    iphdr_data->tot_len = IPHDR_SIZE + TCPHDR_SIZE;
    iphdr_data->id = htons(54321);
    iphdr_data->frag_off = htons(16384);
    iphdr_data->ttl = 64;
    iphdr_data->protocol = IPPROTO_TCP;
    iphdr_data->check = 0;
    iphdr_data->saddr = inet_addr(gSourceIp);
    iphdr_data->daddr = gDstIp.s_addr;
    iphdr_data->check = CalChecksum((uint16_t *)datagram, iphdr_data->tot_len >> 1);
}
void InitTcpHdr(struct tcphdr *tcphdr_data) {
    tcphdr_data->source = htons(gSourcePort);
    tcphdr_data->dest = htons(80);
    tcphdr_data->seq = htonl(1105024978);
    tcphdr_data->ack_seq = 0;
    tcphdr_data->doff = TCPHDR_SIZE / 4;
    tcphdr_data->window = htons(14600);
    tcphdr_data->check = 0;
    tcphdr_data->urg_ptr = 0;
}
void SendToDst(int port, int flags) {
    gTcphdr->dest = htons(port);
    gTcphdr->check = 0;
    gTcphdr->th_flags = flags; 
    memcpy(&gPsdhdr->tcp, gTcphdr, TCPHDR_SIZE);
    gTcphdr->check = CalChecksum((uint16_t *)gPsdhdr, PSD_SIZE);
    struct sockaddr_in dst;
    dst.sin_family = AF_INET;
    dst.sin_addr.s_addr = gDstIp.s_addr;
    // 发送报文给目标主机
    if (sendto(gSockfd, gDatagram, IPHDR_SIZE + TCPHDR_SIZE, 0, (struct sockaddr *)&dst, sizeof(dst)) < 0) {
        herror("send package fails:");
        exit(0);
    }
}
void *GetPackage() {
    int saddr_size, data_size;
    struct sockaddr saddr;
    uint8_t *buffer = (uint8_t *)malloc(MAX_SIZE);
    // 创建原始套接字以接收报文
    int sock_raw = socket(AF_INET, SOCK_RAW, IPPROTO_TCP);
    if (sock_raw < 0) {
        perror("sock create fails:");
        exit(0);
    }
    struct timeval timeout;
    timeout.tv_sec = 1;
    timeout.tv_usec = 0;
    setsockopt(sock_raw, SOL_SOCKET, SO_RCVTIMEO, &timeout, sizeof(timeout));
    saddr_size = sizeof(saddr);
    if (gFlag == FIN_TYPE) {
        for (int i = 1; i < 65536; ++i) {
            gTotalPorts[i] = 1;
        }
    }
    for (int i = 0; i < gPorts; ++i) {
        // 监听端口，解析报文
        printf("\b");
        data_size = recvfrom(sock_raw, buffer, MAX_SIZE, 0, &saddr, &saddr_size);
        if (data_size >= 0) {
            ProcessPacket(buffer, data_size);
            fflush(stdout);
        } else {
            continue;
        }
    }
    close(sock_raw);
    free(buffer);
    fflush(stdout);
}
void ProcessPacket(uint8_t *buffer, int size){
    struct iphdr *iphdr_data = (struct iphdr *)buffer;
    struct sockaddr_in src, dst;
    uint16_t iphdr_len;
    if (iphdr_data->protocol == 6) {
        struct iphdr *iphdr_data = (struct iphdr *)buffer;
        iphdr_len = iphdr_data->ihl*4;
        struct tcphdr *tcphdr_data = (struct tcphdr *)(buffer + iphdr_len);   
        memset(&src, 0, sizeof(src));
        src.sin_addr.s_addr = iphdr_data->saddr;
        memset(&dst, 0, sizeof(dst));
        dst.sin_addr.s_addr = iphdr_data->daddr;   
        if (gFlag == SYN_TYPE) {
            if ((tcphdr_data->syn == 1) && 
                (tcphdr_data->ack == 1) && 
                (src.sin_addr.s_addr == gDstIp.s_addr)
                ) {
                int port = ntohs(tcphdr_data->source);
                // printf("Port %d open\n", port);
                printf(".");
                // 发送RST给目标主机
                gTotalPorts[port] = 1;
                SendToDst(port, 0x4);
            }
        } else if (gFlag == FIN_TYPE) {
            if ((tcphdr_data->rst == 1) && 
                (src.sin_addr.s_addr == gDstIp.s_addr)
                ) {
                int port = ntohs(tcphdr_data->source);
                // printf("Port %d closed\n", port);
                printf(".");
                gTotalPorts[port] = 0;
            }            
        }
    }
}
// 计算IP报文或TCP报文校验和
uint16_t CalChecksum(uint16_t *data, int nbytes) {
    register long sum = 0;
    uint16_t oddbyte;
    register short answer;
    while (nbytes > 1) {
        sum += *data++;
        nbytes -= 2;
    }
    if (nbytes == 1) {
        oddbyte = 0;
        *((u_char*)&oddbyte) = *(u_char*)data;
        sum += oddbyte;
    }
    sum = (sum >> 16) + (sum & 0xffff);
    sum = sum + (sum>>16);
    answer = (unsigned short)(~sum);
    return answer;
}
char *GetHostByName(char *hostname) {
    struct hostent *he;
    struct in_addr **addr_list;
    if ((he = gethostbyname(hostname)) == NULL) {
        herror("gethostbyname");
        return NULL;
    }
    addr_list = (struct in_addr **) he->h_addr_list;
    for (int i = 0; addr_list[i] != NULL; i++) {
        return inet_ntoa(*addr_list[i]) ;
    }
    return NULL;
}
int GetLocalIp(char *dst) {
    int sock = socket(AF_INET, SOCK_DGRAM, 0);
    struct sockaddr_in serv;
    memset(&serv, 0, sizeof(serv));
    serv.sin_family = AF_INET;
    serv.sin_addr.s_addr = inet_addr(cDnsIp);
    serv.sin_port = htons(53); // DNS端口
    int err = connect(sock, (const struct sockaddr *)&serv, sizeof(serv));
    struct sockaddr_in name;
    socklen_t namelen = sizeof(name);
    err = getsockname(sock, (struct sockaddr*)&name, &namelen);
    inet_ntop(AF_INET, &name.sin_addr, dst, 100);
    printf("Local host IP address is %s \n", dst);
    close(sock);
}

int Scan(char *dst_ip, int begin_port, int end_port, int scan_type) {
    InitDstIp(dst_ip);
    GetLocalIp(gSourceIp);
    gPorts = end_port - begin_port + 1;
    printf("\n%d ports to be scan\n", gPorts); 
    if (scan_type == TCP_SCAN) {
        for (int port = begin_port; port <= end_port; ++port) {
            struct sockaddr_in dst;
            dst.sin_family = AF_INET;
            dst.sin_addr.s_addr = gDstIp.s_addr;
            dst.sin_port = htons(port);
            int sockfd, flags, res;
            fd_set fdr, fdw;
            struct timeval timeout;
            sockfd = socket(AF_INET, SOCK_STREAM, 0);
            if (sockfd < 0) {
                perror("create socket fails");
                return -1;
            }
            flags = fcntl(sockfd, F_GETFL, 0);
            fcntl(sockfd, F_SETFL, flags | O_NONBLOCK);
            if (connect(sockfd, (struct sockaddr *)&dst, sizeof(dst)) == 0) {
                // printf("Port %d open\n", port);
                gTotalPorts[port] = 1;
                close(sockfd);
                continue;
            }
            FD_ZERO(&fdr);
            FD_ZERO(&fdw);
            FD_SET(sockfd, &fdr);
            FD_SET(sockfd, &fdw);
            timeout.tv_sec = 1;
            timeout.tv_usec = 0;
            res = select(sockfd + 1, &fdr, &fdw, NULL, &timeout);
            if (res < 0) {
                perror("select error");
                close(sockfd);
                return -1;
            } else if (res == 1) {
                if(FD_ISSET(sockfd, &fdw)) {
                    gTotalPorts[port] = 1;
                }
            }
            close(sockfd);
        }
    } else {
        gSockfd = socket(AF_INET, SOCK_RAW, htons(ETH_P_IP));
        if (gSockfd < 0) {
            perror("create socket fails");
            exit(0);
        }
        gIphdr  = (struct iphdr  *)(gDatagram);
        gTcphdr = (struct tcphdr *)(gDatagram + IPHDR_SIZE);
        gPsdhdr = (struct psdhdr *)(malloc(PSD_SIZE));
        InitIpHdr(gIphdr, gDatagram);
        InitTcpHdr(gTcphdr);
        InitPSDhdr(gPsdhdr);
        // 报文中包含首部
        int one = 1;
        const int *val = &one;
        if (setsockopt(gSockfd, IPPROTO_IP, IP_HDRINCL, val, sizeof(one)) < 0){
            perror("setting IP_HDRINCL fails:");
            exit(0);
        }
        // 创建监听进程
        pthread_t tid;
        if (pthread_create(&tid, NULL, GetPackage, NULL) < 0){
            perror("Create Thread fails:");
            exit(0);
        }
        if (scan_type == SYN_SCAN) {
            gFlag = SYN_TYPE;
        } else if (scan_type == FIN_SCAN) {
            gFlag = FIN_TYPE;
        }
        for (int port = begin_port; port <= end_port; ++port) {
            SendToDst(port, gFlag);
        }
        pthread_join(tid, NULL);
        close(gSockfd);
        free(gPsdhdr);
    }
    int cnt = 0;
    for (int port = begin_port; port <= end_port; ++port) {
        if (gTotalPorts[port] == 1) {
            printf("Port %d open\n", port);
        } else {
            cnt++;
        }
    }
    printf("%d ports closed\n", cnt);
    return 0;
}
