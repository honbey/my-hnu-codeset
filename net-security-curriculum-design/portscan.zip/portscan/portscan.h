#ifndef PORTSCAN_PORTSCAN_H
#define PORTSCAN_PORTSCAN_H

#include <stdio.h>
#include <unistd.h>
#include <stdlib.h>
#include <string.h>
#include <sys/socket.h>
#include <sys/ioctl.h>
#include <fcntl.h>
#include <errno.h>
#include <pthread.h>
#include <netdb.h>
#include <arpa/inet.h>
#include <netinet/tcp.h>
#include <netinet/ip.h>
#include <netinet/ether.h>
#include <time.h>

//use for CalChecksum
struct psdhdr {
    uint32_t src_addr;
    uint32_t dst_addr;
    uint8_t placeholder;
    uint8_t protocol;
    uint16_t tcp_length;
    struct tcphdr tcp;
};

void InitIpHdr(struct iphdr *iphdr_data, char *datagram);
void InitTcpHdr(struct tcphdr *tcphdr_data);
void InitPSDhdr(struct psdhdr *psdhdr_data);
void InitDstIp(char *target);
uint16_t CalChecksum(uint16_t *data, int size);
void *GetPackage();
void SendToDst(int port, int flags);
void ProcessPacket(uint8_t *buffer, int size);
char *GetHostByName(char *hostname);
int GetLocalIp(char *dst);

int Scan(char *dst_ip, int begin_port, int end_port, int scan_type);

#define TCPHDR_SIZE sizeof(struct tcphdr)
#define IPHDR_SIZE  sizeof(struct iphdr)
#define PSD_SIZE    sizeof(struct psdhdr)

#define MAX_SIZE 65536

#define TCP_SCAN 0
#define SYN_SCAN 1
#define FIN_SCAN 2
#define UDP_SCAN 3

#define FIN_TYPE 0x01
#define SYN_TYPE 0x02
#define RST_TYPE 0x04
#define PSH_TYPE 0x08
#define ACK_TYPE 0x10
#define UGR_TYPE 0x20

#endif // PORTSCAN_PORTSCAN_H
