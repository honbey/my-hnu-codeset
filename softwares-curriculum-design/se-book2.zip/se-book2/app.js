const express = require("express");
const path = require("path");
const bodyParser = require("body-parser");
const session = require("express-session");
// build server
const app = express();
// database
require("./model/mongodb");
// hand post
app.use(bodyParser.urlencoded({extended: false}));

app.use(session( {
    secret: "book2 system",
    saveUninitialized: false,
    cookie: {
        maxAge: 259200000 // 3*24*60*60*1000 = 3 days
    }
}));

// default folder path of template
app.set("views", path.join(__dirname, "views"));
app.set("view engine", "art");
app.engine("art", require("express-art-template"));

app.use(express.static(path.join(__dirname, "public")));

const index = require("./route");
const users = require("./route/users");

// 判断用户登录状态
app.use("/user", require("./middleware/guard"));

// import route module
app.use("/", index);
app.use("/user", users);

app.use((err, req, res, next) => {
    const result = JSON.parse(err);
    let params = [];
    for (let iter in result) {
        if (iter != "path") {
            params.push(iter + "=" + result[iter]);
        }
    }
    res.redirect(`${result.path}?${params.join("&")}`);
})

// 重定向404
app.get("*", function(req, res) {
    res.status(404).render("user/error", {msg: "404，找不到该页面"});
});
// listen port and start
app.listen(2999);
console.log("Server Start Successfully!");
