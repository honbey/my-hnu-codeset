const express = require("express");
const user = express.Router();

// 登录验证
user.post("/login", require("./user/login"));
// 控制台
user.get("/dashboard", require("./user/dashboard"));
// 用户管理界面
user.get("/manage", require("./user/manage"));
// 用户注销
user.get("/logout", require("./user/logout"));
// 用户编辑
user.post("/edit", require("./user/edit"));
// 资料管理
user.get("/resources", require("./user/resources"));
// 资料上传
user.post("/upload", require("./user/upload"));

module.exports = user;
