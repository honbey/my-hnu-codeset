// const { User } = require("../../model/user");
const { Resource } = require("../../model/resource");

module.exports = async(req, res) => {
    const { id, userid } = req.query;
    try {
        if (id && userid) {
            await Resource.updateOne({_id: id}, {"$push": {
                comment: {
                    userid: userid,
                    index: req.body.index,
                    username: req.body.username,
                    text: req.body.text,
                    time: req.body.time
                }
            }});
            res.send( {
                code: "200",
                result: "评论成功！", // "update successfully"
            });
        }
    } catch(error) {
        res.send( {
            code: "400",
            result: error.message
        });
    }
}
