const { Resource } = require("../../model/resource");

module.exports = async(req, res) => {
    const { m } = req.query;
    if (m) {
        // 根据不同参数查询不同类型的资源
        if (m == "task") {
            var resources = await Resource.find({"rstype.name": "task"}).populate("author");
            var subtitle = "学习任务";
        } else if (m == "resource") {
            var resources = await Resource.find({"rstype.name": "resource"}).populate("author");
            var subtitle = "学习课件";
        } else {
            var resources = await Resource.find({"rstype.name": "communication"}).populate("author");
            var subtitle = "交流讨论";
        }
    } else {
        var resources = await Resource.find({}).populate("author");
        var subtitle = " 教学辅助系统";
    }
    // res.send(resources);
    if (req.session._id) {
        var second = '<a href="/user/manage" style="font-size:15px">个人信息</a>';
        var third  = '<a href="/user/logout" style="font-size:15px">注销</a>';
    }
    res.render("index/home", {
        resources, subtitle, second, third
    });
}
