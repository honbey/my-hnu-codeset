const bcrypt = require("bcrypt");
const { User, validRule } = require("../../model/user");

module.exports = async(req, res) => {
    let ubody = {
        username: req.body.username,
        email: req.body.email,
        role: "student",
        state: 1,
        sid: req.body.sid,
        password: req.body.password
    }
    try {
        await validRule(ubody);
    } catch (e) {
        res.send( {
            code: "400",
            result: e.message
        });
    }
    let user = await User.findOne({ email: ubody.email });
    if (user) {
        res.send( {
            code: "400",
            result: "邮件地址已被注册"
        });
    } else {
        const salt = await bcrypt.genSalt();
        const password = await bcrypt.hash(ubody.password, salt);
        ubody.password = password;
        await User.create(ubody);
        res.send( {
            code: "200",
            result: "注册成功，请关闭此窗口后登录"
        });
    }
}