const { Resource } = require("../../model/resource");

module.exports = async(req, res) => {
    const { id } = req.query;
    let resource = await Resource.findOne({_id: id}).populate("author");
    if (req.session._id) {
        var first  = '<a href="/" style="font-size:15px">返回首页</a>';
        var second = '<a href="/user/manage" style="font-size:15px">个人信息</a>';
        var third  = '<a href="/user/logout" style="font-size:15px">注销</a>';
        var comment = `<form>
                            <div class="group-form">
                                <div class="group-content w9" name="comment">
                                    <textarea name="comment" id="comment"></textarea>
                                </div>
                            </div>
                            <div class="group-form">
                                <div class="group-content">
                                    <input id="comment" type="button" class="btn btn-green mr20" onclick="submitForm('/comment?id=` + id +`&userid=` + req.session._id + `','post','reset');" value="提交">
                                    <input id="reset" type="reset" class="btn btn-orange" value="重置">
                                </div>
                            </div>
                        </form>`
        var username = req.session.username;
    }
    res.render("index/article", {
        resource, first, second, third, comment, username
    });
}