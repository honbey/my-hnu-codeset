const execSync = require("child_process").execSync;
const nodemailer  = require("nodemailer");

// 参数：发件人，收件人，主题，正文（支持html格式）
function sendMail(from, aliasName, tos, subject, msg) {
    const smtpTransport = nodemailer.createTransport( {
        host: "smtp.qq.com",
        secureConnection: true,
        secure: true,
        port: 465,
        auth: {
            user: from,
            pass: process.env.QQ_MAIL_PASSWD,
        }
    });

    smtpTransport.sendMail( {
        // from    : '标题别名 <foobar@latelee.org>',
        from    : aliasName + " " + "<" + from + ">",
        to      : tos,
        subject : subject,
        html    : msg
    }, function(err, res) {
        if (err) {
            console.log("error: ", err);
        }
    });
}

module.exports = async(req, res) => {
    try {
        const { m, n } = req.query;
        // 产生验证码
        if (m == "phone") {
            var vcode = Math.ceil((Math.random()*9+1)*100000).toString();
            const result = execSync("python3 /home/honbey/workspace/msg.py" + " " + n + " " + vcode);
        } else if (m == "email") {
            var vcode = Math.ceil((Math.random()*9+1)*100000).toString();
            sendMail("no-reply@freewisdom.cn", 
                "BOOK2管理员", 
                n, 
                "用户注册", 
                '您的验证码为'+ vcode +'，验证码有效期为十分钟。如非本人操作，请忽略此信息。<h2> BOOK2 主页：</h2><a href= book2.freewisdom.cn" target="_blank">book2.freewisdom.cn</a></br>'
            );
        }
        // console.log(result.toString());
        // 设想的方案是把 vcode 经过 Hash 后发送到客户端，客户端对输入的验证码也进行相同的操作，验证无误才可以提交注册
        // 现阶段暂时明文发送
        res.send( {
            code: "200",
            vcode: vcode,
            result: "发送成功！"
        });
    } catch(e) {
        res.send( {
            code: "400",
            result: e.message
        });
    }
}
