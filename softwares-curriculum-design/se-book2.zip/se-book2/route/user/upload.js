const { Resource } = require("../../model/resource");

module.exports = async(req, res) => {
    req.body.attachment = JSON.parse(req.body.attachment);
    req.body.rstype     = JSON.parse(req.body.rstype);
    const { id, m } = req.query;
    try {
        if (id && m) {
            let resource = await Resource.findOne({_id: id});
            if (m == "edit") {
                res.send(resource);
            } else if (m == "delete") {
                await Resource.findOneAndDelete({_id: id});
                res.send( {
                    code: "200",
                    result: "删除成功！" // "delete successfully"
                });
            } else if (m == "update") {
                await Resource.updateOne({_id: id}, {
                    title: req.body.title,
                    rstype: req.body.rstype,
                    attachment: req.body.attachment,
                    content: req.body.content
                });
                res.send( {
                    code: "200",
                    result: "修改成功！" // "update successfully"
                });
            }
        } else {
            await Resource.create(req.body);
            res.send( {
                code: "200",
                result: "添加成功！" // "create successfully"
            });
        }
    } catch(error) {
        res.send( {
            code: "400",
            result: error.message
        });
    }
}