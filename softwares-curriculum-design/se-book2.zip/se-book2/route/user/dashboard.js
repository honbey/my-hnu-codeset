var os=require('os');

module.exports = async(req, res) => {
    req.app.locals.currentlink = "dashboard";
    let userName = os.userInfo().username || "";
    let hostIP   = "106.52.96.74";
    let localIP  = req.headers['x-wq-realip'] || req.connection.remoteAddress || req.socket.remoteAddress || req.connection.socket.remoteAddress || "";
    let hostname = os.hostname() || "";
    let userdir  = os.homedir() || "";
    let memrate  = (((os.totalmem()-os.freemem()) / os.totalmem()) * 100) + "%" || "";
    let server   = process.title + " " + process.version || "";
    let osType   = os.type() + " " + os.arch() + " " + os.release() || "";
    res.render("user/dashboard", {
        subtitle: " | " + "Dashboard",
        hostIP: hostIP,
        localIP: localIP,
        userName: userName,
        hostname: hostname,
        userdir: userdir,
        memrate: memrate,
        server: server,
        osType: osType,
        username: req.session.username
    });
}