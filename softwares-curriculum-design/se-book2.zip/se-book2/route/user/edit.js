const bcrypt = require("bcrypt");
const { User, validRule } = require("../../model/user");

module.exports = async(req, res) => {
    req.app.locals.currentlink = "manage";
    const { id, m } = req.query;
    try {
        if (id && m) {
            let user = await User.findOne({_id: id});
            if (m == "edit") {
                res.send( {
                    _id: user._id,
                    username: user.username,
                    email: user.email,
                    role: user.role,
                    state: user.state,
                    sid: user.sid
                });
            } else if (m == "update") {
                let isValid = false;
                if (req.session.role == "admin" || req.session.role == "teacher") {
                    isValid = true;
                } else {
                    isValid = await bcrypt.compare(req.body.password, user.password);
                }
                if (isValid) {
                    await User.updateOne({ _id: id }, {
                        username: req.body.username,
                        email: req.body.email,
                        role: req.body.role,
                        state: req.body.state
                    });
                    res.send( {
                        code: "200",
                        result: "修改成功！" // "update successfully"
                    });
                } else {
                    res.send( {
                        code: "400",
                        result: "用户权限不够！" // "update failed"
                    });
                }
            } else if (m == "delete") {
                await User.findOneAndDelete({_id: id});
                res.send( {
                    code: "200",
                    result: "删除成功！" // "delete successfully"
                });
            }
        } else {
            let ubody = {
                username: req.body.username,
                email: req.body.email,
                role: req.body.role,
                state: req.body.state,
                sid: req.body.sid,
                password: req.body.password
            }
            try {
                await validRule(ubody);
            } catch (e) {
                throw new Error(e)
            }
            let user = await User.findOne({ email: ubody.email });
            if (user) {
                res.send( {
                    code: "400",
                    result: "邮件地址已被注册"
                });
            } else {
                const salt = await bcrypt.genSalt();
                const password = await bcrypt.hash(ubody.password, salt);
                ubody.password = password;
                await User.create(ubody);
                res.send( {
                    code: "200",
                    result: "用户添加成功"
                });
            }
        }
    } catch(error) {
        res.send( {
            code: "400",
            result: error.message
        });
    }
}