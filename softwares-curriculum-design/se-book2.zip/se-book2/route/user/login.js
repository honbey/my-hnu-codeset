const bcrypt = require("bcrypt");
// 导入数据库对象的构造函数
const { User } = require("../../model/user")

module.exports = async(req, res) => {
    // res.send(req.body);
    const {email, password} = req.body;
    if (email.trim().length == 0 || password.trim().length == 0) {
        // return res.status(400).send("<h4>邮件地址或密码不能为空！</h4>");
        return res.status(400).render("user/error", {msg: "邮件地址或密码不能为空！"});
    }
    // 异步等待
    let user = await User.findOne({ email })
    if (user) {
        let isValid = await bcrypt.compare(password, user.password);
        if (isValid) {
            // 将用户名存储在请求对象中
            req.session.username = user.username;
            req.session.role = user.role;
            req.session._id = user._id;
            req.session.state = user.state;
            req.app.locals.userInfo = user; // 使用这个对象会导致失效的访问控制
            // res.send("登录成功");
            // 重定向页面
            res.redirect("/user/manage");
        } else {
            res.status(400).render("user/error", {msg: "邮件地址或密码错误！"});
        }
    } else {
        // can not find the user
        res.status(400).render("user/error", {msg: "邮件地址或密码错误！"});
    }
}