const { User } = require("../../model/user");

module.exports = async(req, res) => {
    req.app.locals.currentlink = "manage";
    let page = req.query.page || 1;
    let size = 5; // 每一页显示多少条数据
    // 学生只能更改个人信息，管理员可以管理所有人的信息，教师能管理所有学生的信息
    if (req.session.role == "admin") {
        var users = await User.find({}).limit(size).skip((page - 1) * size);
        var count = await User.countDocuments({});
    } else if (req.session.role == "teacher") {
        var users = await User.find({"role": "student"}).limit(size).skip((page - 1) * size);
        var count = await User.countDocuments({"role": "student"});
    }
    let total = Math.ceil(count / size);
    res.render("user/manage", {
        users: users,
        page: page,
        total: total,
        count: count,
        subtitle: " | " + "用户管理",
        username: req.session.username
    });
}