// const { User } = require("../../model/user");
const { Resource } = require("../../model/resource");

module.exports = async(req, res) => {
    req.app.locals.currentlink = "resources";
    let page = req.query.page || 1;
    let size = 5; // 每一页显示多少条数据
    // let 作用域为的是块级作用域，所以下面使用的是var
    if (req.session.role == "admin") {
        var resources = await Resource.find({}).populate("author").limit(size).skip((page - 1) * size);
        var count = await Resource.countDocuments({});
    } else if (req.session.state == 0) {
        var resources = await Resource.find({"author": req.session._id}).populate("author").limit(size).skip((page - 1) * size);
        var count = await Resource.countDocuments({"author": req.session._id});
    } else {
        return res.render("user/error", {
            msg: "账号未启用，不能发布资源，请联系管理员或教师以启用账号！"
        });
    }
    let total = Math.ceil(count / size);
    // res.send(resources);
    res.render("user/resources", {
        resources: resources,
        page: page,
        total: total,
        count: count,
        subtitle: " | " + "资源管理",
        username: req.session.username
    });
}