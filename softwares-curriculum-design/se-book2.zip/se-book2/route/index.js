const express = require("express");
const index = express.Router();

// 主页
index.get("/", require("./index/home"));
// 资源详情
index.get("/article", require("./index/article"));
// 提交评论
index.post("/comment", require("./index/comment"));
// 用户信息验证
index.post("/send", require("./index/send"));
// 用户自行注册
index.post("/signup", require("./index/signup"));

module.exports = index;
