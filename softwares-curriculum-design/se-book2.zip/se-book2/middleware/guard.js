module.exports = (req, res, next) => {
    if (req.url != "/login" && !req.session.username) {
        res.redirect("/");
    } else {
        if ((req.path == "/dashboard") && req.session.role != "admin") {
            return res.redirect("/user/manage");
        }
        // 放行
        next();
    }
}