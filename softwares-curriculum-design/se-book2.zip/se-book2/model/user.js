const mongoose = require("mongoose");
const bcrypt = require("bcrypt");
const joi = require("joi");

// user set rule
const userSchema = new mongoose.Schema( {
    username: {
        type: String,
        required: true,
        minlenght: 2,
        maxlenght: 30
    },
    email: {
        type: String,
        required: true,
        unique: true
    }, 
    sid: {
        type: String,
        required: true,
        unique: true
    },
    password: {
        type: String,
        required: true
    },
    // admin: super admin
    // teacher
    // student
    role: {
        type: String,
        required: true
    },
    // 0 active
    // 1 forbidden
    state: {
        type: Number,
        default: 0
    }
});

// user set
const User = mongoose.model("User", userSchema);

// async function createUser() {
//     const salt = await bcrypt.genSalt();
//     const pawd = await bcrypt.hash("123456aA.", salt);
//     const user = await User.create({
//         username: "admin", // superadmin
//         email: "admin@book2.cn", // admin@freewisdom.cn
//         password: pawd, // 123456
//         sid: "2017201709",
//         role: "admin",
//         state: 0
//     }).then(() => {
//         console.log("User create successfully!")
//     }).catch(() => {
//         console.log("User create failed!")
//     });
// }
// createUser();

const validRule = user => {
    const schema = {
        username: joi.string().min(2).max(30).required().error(new Error("用户名不符合要求")),
        email: joi.string().email().required().error(new Error("邮箱格式不正确")),
        password: joi.string().regex(/^(?=.*?[A-Z])(?=.*?[a-z])(?=.*?[0-9])(?=.*?[^\w\s]).{8,20}$/).required().error(new Error("密码不符合要求！")),
        role: joi.string().valid("admin", "student", "teacher").required().error(new Error("角色值非法")),
        state: joi.number().valid(0, 1).required().error(new Error("状态值非法")),
        sid: joi.string().regex(/^\d{6,10}$/).required().error(new Error("学号/工号值非法"))
    };
    return joi.validate(user, schema);
}

// let user set export as member
module.exports = {
    User,
    validRule
}