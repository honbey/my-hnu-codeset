const mongoose = require("mongoose");

const resourceSchema = new mongoose.Schema( {
    title: {
        type: String,
        minlength: 2,
        maxlength: 100,
        required: [true, "请填写资源名"]
    },
    rstype: {
        type: Object,
        default: {
            name: "resource",
            option: "public"
        },
        required: [true, "请确认类型"]
    },
    author: {
        type: mongoose.Schema.Types.ObjectId,
        ref: "User",
        required: [true, "作者不能为空"]
    },
    attachment: {
        type: Array,
        default: null
    },
    content: {
        type: String,
        default: "BOOK2"
    },
    comment: {
        type: Array,
        default: null
    }
});

const Resource = mongoose.model("Resource", resourceSchema);

// async function uploadRS() {
//     const testrs = await Resource.create({
//         title: "资源测试2",
//         author: "5ef84830e5690f08224d0ca6",
//     }).then(() => {
//         console.log("Create successfully!")
//     }).catch((e) => {
//         console.log(e.message)
//     });
// }
// uploadRS();

module.exports = {
    Resource
}