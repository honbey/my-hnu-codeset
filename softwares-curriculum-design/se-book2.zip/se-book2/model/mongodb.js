const mongoose = require("mongoose");

const USER = process.env.USER;
const PASSWD = process.env.MONGODB_PASSWD;

mongoose.set('useCreateIndex', true)
mongoose.connect("mongodb://" + USER + ":" +  PASSED + "@106.52.96.74:3000/book2?authSource=admin", {useNewUrlParser: true, useUnifiedTopology: true})
    .then(() => console.log("Database Connect Successfully!"))
    .catch(() => console.log("Database Connect Failed!"))
