ice.use("popup");
function loginWindow() {
    var html ='<form class="form-container" action="/user/login" method="post" id="loginForm">';
    html += '<div class="group-input"><div class="group-label">邮箱</div><div class="group-content"><input type="email" name="email" placeholder="请输入邮箱" value=""></div></div>';
    html += '<div class="group-input"><div class="group-label">密码</div><div class="group-content"><input type="password" name="password" placeholder="请输入密码" value=""></div></div>';
    html += '<div class="group-form"><div class="group-label"></div><div class="group-content"><input type="submit" class="btn btn-green mr20" value="登录"></div></div>';
    html += '</form>';
    
    ice.popup( {
        title: "用户登录",
        content: html
    });
}
function signupWindow() {
    var html = '<div class="group-input"><div class="group-label">姓名</div><div class="group-content"><input type="text" name="username" placeholder="请输入真实姓名"></div></div>';
    html += '<div class="group-input"><div class="group-label">邮箱</i></div><div class="group-content"><input type="email" name="email" placeholder="请输入邮箱"></div><a href="javascript:sendEmailCode();" class="btn btn-green" id="ecsend">发送验证码</a></div>';
    html += '<div class="group-input"><div class="group-label">验证码</i></div><div class="group-content"><input type="ecode" name="ecode" placeholder="请输入邮箱验证码"></div></div>';
    html += '<div class="group-input"><div class="group-label">手机号</i></div><div class="group-content"><input type="phone" name="phone" placeholder="请输入手机号"></div><a href="javascript:sendPhoneCode();" class="btn btn-green" id="pcsend">发送验证码</a></div>';
    html += '<div class="group-input"><div class="group-label">验证码</i></div><div class="group-content"><input type="pcode" name="pcode" placeholder="请输入手机验证码"></div></div>';
    html += '<div class="group-input"><div class="group-label">学号</i></div><div class="group-content"><input type="text" name="sid" placeholder="请输入学号"></div></div>';    
    html += '<div class="group-input"><div class="group-label">密码</i></div><div class="group-content"><input type="password" name="password" placeholder="请输入密码"></div></div>';
    html += '<div class="group-input"><div class="group-label">密码</i></div><div class="group-content"><input type="password" name="password_" placeholder="请确认密码"></div></div>';    
    html += '<div class="group-form"><div class="group-label"></div><div class="group-content"><a href="javascript:signupForm();" class="btn btn-blue" id="signup">注册</a></div>';
    
    ice.popup( {
        height: "360px",
        title: "用户注册",
        content: html
    });
}

function popupDel(url) {
    ice.popup( {
        title: "请再次确认",
        content: "此操作将删除这一资源/用户",
        btn: ["取消", "确认"],
        color: "red",
        yes: function () {
            submitForm(url, "post", "reset");
        },
        no: function () {}
    });
}

function serialize2JSON(form) {
    var result = {};
    // {name: "email", value: "content"}
    var f = form.serializeArray();
    f.forEach(function(item) {
        // result.email
        result[item.name] = item.value;
    });
    return result;
}