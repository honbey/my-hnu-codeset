import sys
from ucloud.core import exc
from ucloud.client import Client

number = sys.argv[1]
code   = sys.argv[2]

UCLOUD_PUBLIC_KEY = os.getenv('UCLOUD_PUBLIC_KEY')
UCLOUD_PRIVATE_KEY = os.getenv('UCLOUD_PRIVATE_KEY')
UCLOUD_PROJECT_ID = os.getenv('UCLOUD_PROJECT_ID')
UCLOUD_SMS_SIGNATURE = os.getenv('UCLOUD_SMS_SIGNATURE')
UCLOUD_SMS_TEMPLATE_ID = os.getenv('UCLOUD_SMS_TEMPLATE_ID')

client = Client({
    #-*- encoding: utf-8 -*-
    #配置公私钥
    "region": "cn-bj2",    #地域，默认可不改动
    "public_key": UCLOUD_PUBLIC_KEY,   #SDK公钥
    "private_key": UCLOUD_PRIVATE_KEY, #SDK私钥
    "project_id": UCLOUD_PROJECT_ID,   #项目ID，此处需替换成您自己的项目ID
})

try:
    resp = client.usms().send_usms_message({
        'PhoneNumbers': [number],
	'TemplateParams': [code],
        'SigContent': UCLOUD_SMS_SIGNATURE,   # 短信签名，此处应替换成您自己的短信签名内容
        'TemplateId': UCLOUD_SMS_TEMPLATE_ID, # 短信模板ID，此处应替换成您自己的短信模板ID
    })
except exc.UCloudException as e:
    print(e)
else:
    print(resp)
