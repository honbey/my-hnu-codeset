/******************************************************************************************
 * File Name: image-process.h 
 * 
 * Honbey, honbey@honbey.com
 * Created On 2020-04-09
 * Copyright (c) 2020. All rights reserved.
 * 
 * Interface List:
 * 
 * 
 * Description: 图像处理函数
 * 
 ******************************************************************************************/

#pragma once

// test文件夹下fc文件夹下的图像采用此函数能够得到正确填充的瞳孔图像
cv::Mat IM::getPupil(const cv::Mat &img) {
	// 输出图像统一命名为output
	cv::Mat output;
	// 拷贝图像
	img.copyTo(output);
	// 灰度化
	cv::Mat grayImg = cv::Mat::zeros(img.rows, img.cols, CV_8UC3);
	cv::cvtColor(img, grayImg, cv::COLOR_BGR2GRAY);
	// 图像二值化
	cv::inRange(grayImg, cv::Scalar(30, 30, 30), cv::Scalar(80, 80, 80), grayImg);
	// hierarchy可用可不用，保存轮廓层次，是可选参数
	std::vector<cv::Vec4i> hierarchy;
	// 提取轮廓
	std::vector<std::vector<cv::Point2i>> contours;
	cv::findContours(grayImg, contours, hierarchy, cv::RETR_EXTERNAL, cv::CHAIN_APPROX_SIMPLE, cv::Point(0, 0));

	// 最小范围
	double minArea = 500.0;
	// 轮廓的矩
	std::vector<cv::Moments> moments(contours.size());
	// 确定瞳孔中心并存储
	for (size_t i = 0; i < contours.size(); i++) {
		moments[i] = cv::moments(contours[i], true);
		// 区域面积area，即轮廓的中心矩阵
		double area = moments[i].m00;
		if(area > minArea) {
			cv::drawContours(output, contours, i, cv::Scalar::all(0), cv::FILLED, cv::LINE_8, hierarchy);
			// 得到轮廓的空间矩
			_pupilX = static_cast<int>(moments[i].m10 / moments[i].m00);
			_pupilY = static_cast<int>(moments[i].m01 / moments[i].m00);
		}
	}

	// 返回填充瞳孔后的图像
	return output;
}

cv::Mat IM::getIris(const cv::Mat &img) {
	// 保险起见判断通道数决定是否进行灰度化
	cv::Mat grayImg;
	img.copyTo(grayImg);
	if (img.channels() != 1) {
		cv::cvtColor(grayImg, grayImg, cv::COLOR_BGR2GRAY);
	}
	cv::Canny(grayImg, grayImg, 5, 70, 3);
	cv::GaussianBlur(grayImg, grayImg, cv::Size(7, 7), 0, 0);

	// 定义Hough圆的三元组，圆心x, y以及半径
	cv::Vec3f irisCircle;
	for (int i = 80; i < 151; i++) {
		std::vector<cv::Vec3f> storage;
		cv::HoughCircles(grayImg, storage, cv::HOUGH_GRADIENT, 2, 100.0, 30, i, 100, 120);
		if(storage.size() == 1) {
			irisCircle = storage[0];
			break;
		}
	}

	_irisR = static_cast<int>(irisCircle[2]);
	
	/*
	cv::Mat irisCircleImg = cv::Mat::zeros(img.rows, img.cols, CV_8UC3);
	// 单通道图像转换为三通道图像
	cv::Mat in[] = { img, img, img };
	int from[] = { 
		0, 0, 
		1, 1, 
		2, 2 };
	cv::mixChannels(in, 3, &irisCircleImg, 1, from, 3);
	//std::cout << _irisR << std::endl;
	// 在图像中标识出虹膜，这一步没有输出
	cv::circle(irisCircleImg, cv::Point(_pupilX, _pupilY), _irisR, cv::Scalar(0, 0, 255), 1);
	*/

	// 将无关部分裁剪或填充成黑色 
	// 掩膜图像
	cv::Mat mask = cv::Mat::zeros(grayImg.rows, grayImg.cols, CV_8UC3);
	cv::Mat output;
	img.copyTo(output);
	// 将虹膜区域充填充成黑色
	cv::circle(mask, cv::Point(_pupilX, _pupilY), _irisR, cv::Scalar(255, 255, 255), cv::FILLED);
	// 按位置反
	cv::bitwise_not(mask, mask);
	// 灰度化处理
	cv::cvtColor(mask, mask, cv::COLOR_BGR2GRAY);
	// 利用掩膜图像实现矩阵相减，得到虹膜环
	cv::subtract(img, output, output, mask);
	
	// 定义感兴趣区域
	//r = cv::min(img.rows - _pupilX, _irisR); // 防止图像不规范导致ROI出错
	int x = static_cast<int>(_pupilX - _irisR);
	int y = static_cast<int>(_pupilY - _irisR);
	//std::cout << img.rows << " " << radius << "" << x << std::endl;
	int w = _irisR * 2;
	
	// 图像分割
	output(cv::Rect(x, y, w, w)).copyTo(output);
	// 规范化
	//output = toPolar(output, _irisR);
	
	return output;
}

cv::Mat IM::getPupil(const cv::Mat &img, int houghFlag) {
	houghFlag = _pupilParam;
	cv::Mat output;
	cv::Mat grayImg = cv::Mat::zeros(img.rows, img.cols, CV_8UC3);
	img.copyTo(grayImg);
	img.copyTo(output);
	
	// 预处理，灰度化
	cv::cvtColor(grayImg, grayImg, cv::COLOR_BGR2GRAY);

	// 高斯模糊，计算Hough圆
	cv::GaussianBlur(grayImg, grayImg, cv::Size(7, 7), 3, 3);

	// 储存Hough圆
	std::vector<cv::Vec3f> storage;
	cv::HoughCircles(grayImg, storage, cv::HOUGH_GRADIENT, 2, grayImg.cols / 30, houghFlag, 60, 20, 60);

	// 计算比率
	cv::threshold(grayImg, grayImg, 60, 255, cv::THRESH_BINARY);
	cv::bitwise_not(grayImg, grayImg);
	//std::cout << storage.empty() << std::endl;
	// 利用map储存每个圆的比率及和圆的三元组
	std::map<float, cv::Vec3f> ratio;
	for (auto i = storage.begin(); i != storage.end(); i++) {
		cv::Vec3f c = (*i);
		int X = c[0], Y = c[1], R = c[2];
		int x = X - R;
		int y = Y - R;
		int w = R * 2;
		// 防止越界
		if (0 <= x &&
			0 <= w &&
			0 <= y && 
			x + w <= grayImg.cols &&
			y + w <= grayImg.rows) {

			cv::Mat mask = cv::Mat::zeros(w, w, CV_8UC1);
			grayImg(cv::Rect(x, y, w, w)).copyTo(mask);
			// 计算 非零像素点 / (R * R)
			ratio.insert(std::make_pair((cv::countNonZero(mask) / (R * R)), (*i)));
		}
	}

	// 找到最大的键值，对应的圆即找到瞳孔圆
	auto it = ratio.end();
	it--;
	cv::Vec3f pupilCircle = it->second;
	cv::circle(output, cv::Point(pupilCircle[0], pupilCircle[1]), pupilCircle[2] - 1, cv::Scalar::all(0), cv::FILLED);
	
	// 存储瞳孔信息
	_pupilX = static_cast<int>(pupilCircle[0]);
	_pupilY = static_cast<int>(pupilCircle[1]);
	_pupilR = static_cast<int>(pupilCircle[2]);

	return output;
}

cv::Mat IM::getIris(const cv::Mat &img, int houghFlag) {
	houghFlag = _irisParam; // 虹膜最大半径
	cv::Mat grayImg;
	img.copyTo(grayImg);
	if (img.channels() != 1) {
		cv::cvtColor(grayImg, grayImg, cv::COLOR_BGR2GRAY);
	}

	// 预处理 灰度化以及二值化
	cv::inRange(grayImg, cv::Scalar(60, 60, 60), cv::Scalar(90, 90, 90), grayImg);
	cv::threshold(grayImg, grayImg, 50, 255, cv::THRESH_BINARY);

	// 高斯模糊以及边缘检测
	cv::GaussianBlur(grayImg, grayImg, cv::Size(7, 7), 0, 0);
	cv::Canny(grayImg, grayImg, 5, 70, 3);

	// 计算Hough圆并储存虹膜圆信息
	cv::Vec3f irisCircle;
	for (int i = 80; i < 121; i++) {
		std::vector<cv::Vec3f> storage;
		cv::HoughCircles(grayImg, storage, cv::HOUGH_GRADIENT, 2, 100.0, 30, i, 100, houghFlag);
		// 只检测出一个圆的情况下才是比较吻合的虹膜圆
		if(storage.size() == 1) {
			irisCircle = storage[0];
			break;
		}
	}

	// 存储虹膜信息
	_irisX = static_cast<int>(irisCircle[0]);
	_irisY = static_cast<int>(irisCircle[1]);
	_irisR = static_cast<int>(irisCircle[2]);

	// 将无关部分裁剪或填充成黑色 
	// 掩码图像
	cv::Mat mask = cv::Mat::zeros (grayImg.rows, grayImg.cols, CV_8UC3);
	cv::Mat output;
	img.copyTo(output);
	// 将虹膜区域填充成黑色
	cv::circle(mask, cv::Point(_irisX, _irisY), _irisR, cv::Scalar(255, 255, 255), cv::FILLED);
	cv::bitwise_not(mask, mask);
	cv::cvtColor(mask, mask, cv::COLOR_BGR2GRAY);
	cv::subtract(img, output, output, mask);

	// 定义感兴趣区域
	//r = cv::min(img.rows - x, r);
	int x = _irisX - _irisR;
	int y = _irisY - _irisR;
	int w = _irisR * 2;
	output(cv::Rect(x, y, w, w)).copyTo(output);

	return output;
}


cv::Mat IM::toPolar(cv::Mat img, int radius) {
	// 测试发现最适合本模块的算子
	float k[15] = { 
			-1, 0, 1,
			-1, 0, 1,
			-1, 0, 1,
			-1, 0, 1,
			-1, 0, 1 };
 
 	// 将算子矩阵化
	cv::Mat kernel(5, 3, CV_32F, k);
	// 输入图像是个正方形，半径就是图像尺寸减半
	int xx, yy;
	xx = img.rows / 2;
	yy = img.cols / 2;
	// 符合度较好的一个半径
	double maxRadius = 0.9 * cv::min(yy, xx);
	double M = img.cols / cv::log(maxRadius);
	cv::Mat output = cv::Mat::zeros(radius, 360, CV_8UC3);
	
	// 笛卡尔坐标转换为极坐标
	//cv::logPolar(img, output, cv::Point(xx, yy), M, cv::INTER_LINEAR + cv::WARP_FILL_OUTLIERS + WARP_INVERSE_MAP);
	cv::warpPolar(img, output, cv::Size(), cv::Point(xx, yy), maxRadius, cv::INTER_LINEAR + cv::WARP_FILL_OUTLIERS);
	output(cv::Rect(output.cols / 2, 0, output.cols / 2, output.rows)).copyTo(output);
	
	// 二值化
	cv::filter2D(output, output, 8, kernel, cv::Point(-1, -1));
	cv::threshold(output, output, 0, 255, cv::THRESH_BINARY);
	// 统一图像尺寸
	cv::resize(output, output, cv::Size(60, 360));
	// 输出规范化的图像
	//cv::imshow("Normalization", output);

	return output;
}