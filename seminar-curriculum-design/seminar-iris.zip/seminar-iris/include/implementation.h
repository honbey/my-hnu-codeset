/******************************************************************************************
 * File Name: implementation.h
 * 
 * Honbey, honbey@honbey.com
 * Created On 2019-04-08
 * Copyright (c) 2020. All rights reserved.
 * 
 * Description: A file which easily include all required header files.
 * 
 ******************************************************************************************/

#pragma once

#include "lbp-svm.h"
#include "image-process.h"
#include "MultipleImageWindow.h"