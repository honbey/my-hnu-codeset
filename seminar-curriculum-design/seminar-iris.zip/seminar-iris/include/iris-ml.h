/******************************************************************************************
 * Class Name: IM
 * 
 * Honbey, honbey@honbey.com
 * Created On 2020-04-08
 * Copyright (c) 2020. All rights reserved.
 * 
 * Interface List:
 * 
 * 
 * Description: 实现图像处理和对象检测的类
 * 
 ******************************************************************************************/

#pragma once

#include <iostream>
#include <string>
#include <map>
#include <bitset>
#include <opencv2/opencv.hpp>

#define PUPIL_LIGHT 30
#define IRIS_MAX_R 130
#define LBP_RADIUS 3
#define LBP_NEIGHBORS 8
#define LBP_NUM_PATTERNS 3776
#define LBP_GRID 8
#define DEFAULT_PATH "trainSet/"

class IM {
private:
	int _pupilParam, _irisParam;
	int _pupilX, _pupilY, _pupilR;
	int _irisX, _irisY, _irisR;
	int _radius, _neighbors;
	int _numPatterns, _gridX, _gridY;

protected:
	/**
	 * 规范化虹膜图像，笛卡尔坐标到极坐标的转换，
	 * 此函数是内部函数，参数没有调节好。
	 * 
	 * @param cv::Mat	虹膜图像
	 * @param int 		虹膜半径
	 * @return cv::Mat 	规范化图像
	 */
	cv::Mat toPolar(cv::Mat img, int radius);

	/**
	 * 计算LBP特征值对应图像灰度编码。
	 * 
	 * @param int 		累加器
	 * @return int 		对应累加器的灰度编码值
	 */
	int getHopTimes(int n);

	/**
	 * 计算LBP特征图像块的直方图。
	 * 
	 * @param int 		累加器
	 * @return int 		对应累加器的灰度编码值
	 */
	cv::Mat getLocalRegionLBPH(const cv::Mat &img, int minValue, int maxValue, bool normed);

public:
	/**
	 * Constructor
	 *
	 * 全部使用默认参数
	 */	
	IM() {
		_pupilParam = PUPIL_LIGHT;
		_irisParam = IRIS_MAX_R;
		_radius = LBP_RADIUS;
		_neighbors = LBP_NEIGHBORS;
		_numPatterns = LBP_NUM_PATTERNS;
		_gridX = LBP_GRID;
		_gridY = LBP_GRID;

		train(std::string(DEFAULT_PATH) + std::string("SVM-CHI2.xml"));
	}

	/**
	 * Constructor
	 * 
	 * @param int 				瞳孔参数
	 * @param int 				虹膜参数
	 * @param const std::string 训练集路径
	 */	
	IM(int pupilParam, int irisParam, const std::string &svmPath) {
		_pupilParam = pupilParam;
		_irisParam = irisParam;

		_radius = LBP_RADIUS;
		_neighbors = LBP_NEIGHBORS;
		_numPatterns = LBP_NUM_PATTERNS;
		_gridX = LBP_GRID;
		_gridY = LBP_GRID;

		train(svmPath);
	}

	/**
	 * Constructor
	 * 
	 * @param const std::string 训练集路径
	 */	
	IM(const std::string &svmPath) {
		_pupilParam = PUPIL_LIGHT;
		_irisParam = IRIS_MAX_R;
		_radius = LBP_RADIUS;
		_neighbors = LBP_NEIGHBORS;
		_numPatterns = LBP_NUM_PATTERNS;
		_gridX = LBP_GRID;
		_gridY = LBP_GRID;

		train(svmPath);
	}

	/**
	 * Constructor
	 * 
	 * @param int 瞳孔参数
	 * @param int 虹膜参数
	 */	
	IM(int pupilParam, int irisParam) {
		_pupilParam = pupilParam;
		_irisParam = irisParam;

		_radius = LBP_RADIUS;
		_neighbors = LBP_NEIGHBORS;
		_numPatterns = LBP_NUM_PATTERNS;
		_gridX = LBP_GRID;
		_gridY = LBP_GRID;

		trainAndTest();
	}

	/**
	 * 析构函数
	 * 
	 * OpenCV的C++接口不需要考虑内存泄漏问题，
	 * 此处只是象征性的释放svm。
	 */
	~IM() {
		svm.release();
	}

	/**
	 * 灰度化以及二值化后使用轮廓检测的方法得到瞳孔轮廓，
	 * 判断轮廓面积以选择吻合度最高的轮廓作为瞳孔圆，
	 * 此函数只对trainSet下fc文件夹下的图像有用。
	 * 
	 * @param const cv::Mat& 原图像
	 * @return cv::Mat		 瞳孔被填充的图像
	 */
	cv::Mat getPupil(const cv::Mat &img);

	/**
	 * 灰度化以及高斯模糊后使用Hough变换检测所有可能的圆，
	 * 对每个圆的外切正方形计算非零像素点与正方形面积的比率，
	 * 选择比率最高正方形对应的圆的作为瞳孔圆，
	 * houghFlag参数根据图像明亮程序调节。
	 * 
	 * @param const cv::Mat& 原图像
	 * @param int 			 明亮度阈值
	 * @return cv::Mat		 瞳孔被填充的图像
	 */
	cv::Mat getPupil(const cv::Mat &img, int houghFlag);

	/**
	 * 灰度化以及高斯模糊后使用Hough变换检测圆，
	 * 事先设定的的步长值和阈值能够很好检测到符合度较好虹膜圆，
	 * 虹膜圆使用瞳孔圆圆心以更好的吻合虹膜，
	 * 再使用瞳孔圆圆心和检测到的圆的半径定义感兴趣区域，
	 * 裁剪使用矩阵相减实现，利用掩膜图像保证虹膜不被破坏，
	 * 此函数只对trainSet下fc文件夹下的图像有用。
	 * 
	 * @param const cv::Mat& 灰度图或普通图像
	 * @return cv::Mat		 除虹膜外全黑的图像
	 */
	cv::Mat getIris(const cv::Mat &img);

	/**
	 * 以此对输入图像进行灰度处理，二值化，高斯模糊，边缘检测，
	 * 事先设定的的步长值和阈值能够非常好地检测到虹膜圆，
	 * 使用检测到的圆的圆心及半径定义感兴趣区域，
	 * 裁剪使用矩阵相减实现，利用掩膜图像保证虹膜不被破坏，
	 * 
	 * @param const cv::Mat& 灰度图或普通图像
	 * @param int 			 瞳孔最大半径
	 * @return cv::Mat		 除虹膜外全黑的图像
	 */
	cv::Mat getIris(const cv::Mat &img, int houghFlag);

	/**
	 * 对图像进行等价模式的LBP编码，等价模式复杂度低，提高程序效率。
	 * 
	 * @param const cv::Mat& 灰度图
	 * @return cv::Mat		 局部二值化图
	 */
	cv::Mat getLBPFeature(const cv::Mat &img);

	/**
	 * 提取局部二值化图的特征向量，以便后续的分类，
	 * 将图像8 * 8分块，提取每部分的特征向量，
	 * 
	 * @param const cv::Mat& 局部二值化图
	 * @return cv::Mat		 归一化的特征向量
	 */
	cv::Mat getLBPH(const cv::Mat &img, bool normed);

	// 支持向量机(Support Vector Machine), 机器学习常用框架	
	cv::Ptr<cv::ml::SVM> svm;

	/**
	 * 加载训练好的训练集
	 * 
	 * @param const std::string &svmPath 训练集路径
	 */
	void train(std::string svmPath);

	/**
	 * 对每个分类至少使用8个样本进行训练，多余样本用于测试，
	 * SVM模型使用C类分类器，能够很好的进行多类别训练，
	 * SVM核函数可选择CHI2或LINEAR，
	 * CHI2准确度较高，LINEAR训练速度快，
	 * 训练使用OpenCV内置的trainAuto函数，
	 * 能够找到对应类型和核函数的最优参数以提高准确度。
	 *
	 * @param const std::string &svmPath 训练集路径
	 */
	void trainAndTest();

	/**
	 * 读取文件夹下的图像进行特征提取。
	 *
	 * @param const std::string &svmPath 文件夹路径
	 * @param int 						 样本标签
	 * @param numForTest				 最大测试样本数
	 * @param cv::Mat& 					 训练矩阵
	 * @param std::vector<int> 			 存储样本标签
	 * @param cv::Mat& 					 测试矩阵
	 * @param std::vector<int> 			 测试矩阵的正确结果
	 * @return bool 					 函数执行状态
	 */
	bool readFolderAndExtractFeatures(std::string folder, int label, int numForTest,
	cv::Mat &trainingData, std::vector<int> &responsesData, 
	cv::Mat &testData, std::vector<int> &testResponsesData);

};

#include "implementation.h"