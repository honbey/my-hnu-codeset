/******************************************************************************************
 * File Name: lbp-svm.h 
 * 
 * Honbey, honbey@honbey.com
 * Created On 2020-04-09
 * Copyright (c) 2020. All rights reserved.
 * 
 * Interface List:
 * 
 * 
 * Description: LBP, SVM相关函数
 * 
 ******************************************************************************************/

#pragma once

void IM::train(std::string svmPath) {
	svm = cv::ml::SVM::load(svmPath);
}

int IM::getHopTimes(int n) {
	int count = 0;
	std::bitset<8> binaryCode = n;
	for (int i = 0; i < 8; i++) {
		if (binaryCode[i] != binaryCode[(i + 1) % 8]) {
			count++;
		}	
	}
	return count;
}

cv::Mat IM::getLBPFeature(const cv::Mat &img) {
	cv::Mat output = cv::Mat::zeros(img.rows - 2 * _radius, img.cols - 2 * _radius, CV_8UC1);
	// LBP特征值对应图像灰度编码表，直接默认采样点为8位
	uchar temp = 1;
	uchar table[256] = { 0 };
	for (int i = 0; i < 256; i++) {
		if (getHopTimes(i) < 3) {
			table[i] = temp;
			temp++;
		}
	}

	// 是否进行UniformPattern编码的标志
	bool flag = false;

	// 计算LBP特征图
	for (int k = 0; k < _neighbors; k++) {
		if (k == _neighbors - 1) {
			flag = true;
		}
		// 计算采样点对于中心点坐标的偏移量rx，ry
		float rx = static_cast<float>(_radius * cos(2.0 * CV_PI * k / _neighbors));
		float ry = -static_cast<float>(_radius * sin(2.0 * CV_PI * k / _neighbors));
		// 采样点偏移量分别进行上下取整
		int x1 = static_cast<int>(floor(rx));
		int x2 = static_cast<int>(ceil(rx));
		int y1 = static_cast<int>(floor(ry));
		int y2 = static_cast<int>(ceil(ry));
		// 坐标偏移量映射到0-1之间
		float tx = rx - x1;
		float ty = ry - y1;
		// 根据0-1之间的x，y的权重计算公式计算权重，权重与坐标具体位置无关，与坐标间的差值有关
		float w1 = (1 - tx) * (1 - ty);
		float w2 =    tx    * (1 - ty);
		float w3 = (1 - tx) *    ty;
		float w4 =    tx    *    ty;

		for (int i = _radius; i < img.rows - _radius; i++) { //循环处理每个像素
			for (int j = _radius; j < img.cols - _radius; j++) { //获得中心像素点的灰度值
				uchar center = img.at<uchar>(i, j);
				// 根据双线性插值公式计算第k个采样点的灰度值
				float neighbor = img.at<uchar>(i + x1, j + y1) * w1 + img.at<uchar>(i + x1, j + y2) * w2 \
				+ img.at<uchar>(i + x2, j + y1) * w3 +img.at<uchar>(i + x2, j + y2) * w4;
				// LBP特征图像的每个邻居的LBP值累加，累加通过与操作完成，对应的LBP值通过移位取得
				output.at<uchar>(i - _radius, j - _radius) |= (neighbor > center) << (_neighbors - k - 1);
				// 进行LBP特征的UniformPattern编码
				if (flag) {
					output.at<uchar>(i - _radius, j - _radius) = table[output.at<uchar>(i - _radius, j - _radius)];
				}
			}
		}
	}
	return output;
}

cv::Mat IM::getLocalRegionLBPH(const cv::Mat &img, int minValue, int maxValue, bool normed) {
	// 定义存储直方图的矩阵
	cv::Mat output;
	// 计算得到直方图bin的数目，直方图数组的大小
	int histSize = maxValue - minValue + 1;
	// 定义直方图每一维的bin的变化范围
	float range[] = { static_cast<float>(minValue), static_cast<float>(maxValue + 1) };
	// 定义直方图所有bin的变化范围
	const float* ranges = { range };
	
	// 计算直方图
	cv::calcHist(&img, 1, 0, cv::Mat(), output, 1, &histSize, &ranges, true, false);
	// 归一化
	if(normed) {
		output /= static_cast<int>(img.total());
	}
	// 结果表示成只有1行的矩阵
	return output.reshape(1, 1);
}

cv::Mat IM::getLBPH(const cv::Mat &img, bool normed) {
	int width = img.cols / _gridX;
	int height = img.rows / _gridY;
	// 定义LBPH的行和列，_gridX * _gridY表示将图像分割成块，_numPatterns表示LBP值的模式种类
	cv::Mat output = cv::Mat::zeros(_gridX * _gridY, _numPatterns, CV_32FC1);
	if (img.empty()) {
		return output.reshape(1, 1);
	}
	
	int outputRowIndex = 0;
	// 对图像进行分割，分割成_gridX * _gridY块，_gridX，_gridY默认为8
	for (int i = 0; i < _gridX; i++) {
		for (int j = 0; j < _gridY; j++) {
			// 图像分块
			cv::Mat srcCell = cv::Mat(img, cv::Range(i * height, (i + 1) * height), cv::Range(j * width, (j + 1) * width));
			// 计算直方图
			cv::Mat histCell = getLocalRegionLBPH(srcCell, 0, (_numPatterns - 1), normed);
			// 将直方图放到output中
			cv::Mat rowResult = output.row(outputRowIndex);
			histCell.reshape(1, 1).convertTo(rowResult, CV_32FC1);
			outputRowIndex++;
		}
	}
	// 结果表示成只有1行的矩阵
	return output.reshape(1, 1);
}

void IM::trainAndTest() {
	// 储存特征向量的矩阵
	cv::Mat trainingDataMat, testDataMat;
	// 训练标签
	std::vector<int> responsesData, testResponsesData;

	// 样本数
	int numForTest = 8;

	// 读入负样本并提取特征
	readFolderAndExtractFeatures("trainSet/-/%01d.jpg",
		0, numForTest,
		trainingDataMat, responsesData,
		testDataMat, testResponsesData);
	// 读入正样本并提取特征
	readFolderAndExtractFeatures("trainSet/33/1L/%01d.jpg",
		33, numForTest,
		trainingDataMat, responsesData,
		testDataMat, testResponsesData); // get the nut images
	readFolderAndExtractFeatures("trainSet/48/1R/%01d.jpg",
		48, numForTest,
		trainingDataMat, responsesData,
		testDataMat, testResponsesData);
	readFolderAndExtractFeatures("trainSet/77/1R/%01d.jpg",
		77, numForTest,
		trainingDataMat, responsesData,
		testDataMat, testResponsesData);
	readFolderAndExtractFeatures("trainSet/77/2R/%01d.jpg",
		78, numForTest,
		trainingDataMat, responsesData,
		testDataMat, testResponsesData);
	readFolderAndExtractFeatures("trainSet/91/1L/%01d.jpg",
		91, numForTest,
		trainingDataMat, responsesData,
		testDataMat, testResponsesData);
	readFolderAndExtractFeatures("trainSet/98/2L/%01d.jpg",
		98, numForTest,
		trainingDataMat, responsesData,
		testDataMat, testResponsesData);

	//std::cout << "Num of train samples: 8" << std::endl;
	//std::cout << "Num of test samples: 1"  << std::endl;

	// 将分类标签转化为矩阵
	cv::Mat responsesDataMat, testResponsesDataMat;
	cv::Mat(responsesData).copyTo(responsesDataMat);
	cv::Mat(testResponsesData).copyTo(testResponsesDataMat);
	// 转换类型
	//trainingDataMat.convertTo(trainingDataMat, CV_32FC1);
	responsesDataMat.convertTo(responsesDataMat, CV_32SC1);
	testResponsesDataMat.convertTo(testResponsesDataMat, CV_32FC1);

	//std::cout << trainingDataMat.size() << " " << responsesDataMat.size() << std::endl;

	// 定义SVM参数
	cv::Ptr<cv::ml::TrainData> tdata = cv::ml::TrainData::create(trainingDataMat, cv::ml::ROW_SAMPLE, responsesDataMat);
	svm = cv::ml::SVM::create();
	svm->setType(cv::ml::SVM::C_SVC);
	svm->setNu(0.05);
	svm->setKernel(cv::ml::SVM::CHI2);
	svm->setDegree(1.0);
	svm->setGamma(2.0);
	svm->setTermCriteria(cv::TermCriteria(cv::TermCriteria::MAX_ITER, 100, 1e-6));
	// 选择最优参数训练
	svm->trainAuto(tdata);

	// 读入文件过多的情况下，利用多余图像测试分类器
	if (testResponsesData.size() > 0) {
		std::cout << "Evaluation\n==========" << std::endl;
		cv::Mat testPredict; // test the ML model
		svm->predict(testDataMat, testPredict);
		std::cout << "Prediction Done" << std::endl;
		cv::Mat errorMat = testPredict != testResponsesDataMat;
		float error = 100.0f * cv::countNonZero(errorMat) / testResponsesData.size(); // error calculation
		std::cout << "Error: " << error << "\%" << std::endl;
		//plotTrainData(trainingDataMat, responsesDataMat, &error); // plot training data with error label
	} //else plotTrainData(trainingDataMat, responsesDataMat);

	// 保存训练集
	std::string svmFilename = std::string("SVM.xml");
	svm->save(svmFilename.c_str());
}

bool IM::readFolderAndExtractFeatures(std::string folder, int label, int numForTest,
	cv::Mat &trainingData, std::vector<int> &responsesData, 
	cv::Mat &testData, std::vector<int> &testResponsesData) {
	// 定义一个视频捕获
	cv::VideoCapture cap;
	if (!cap.open(folder)) {
		std::cout << "Can't open the folder images" << std::endl;
		return false;
	}

	// 定义帧图像
	cv::Mat frame;
	int imgIndex = 0;
	for (; cap.read(frame); imgIndex++) {
		// 统一图像大小
		cv::resize(frame, frame, cv::Size(300, 300));
		cv::Mat grayImg;
		// 灰度化
		cv::cvtColor(frame, grayImg, cv::COLOR_RGB2GRAY);
		
		// LBPF编码
		grayImg = getLBPFeature(grayImg);
		// 提取LBP特征向量
		cv::Mat features = getLBPH(grayImg, 1);

		// 根据样本数决定样本是用于训练还是测试
		if (imgIndex < numForTest) {
			trainingData.push_back(features);
			responsesData.push_back(label);
		} else {
			testData.push_back(features);
			testResponsesData.push_back(label);
		}
	}

	// 函数正常结束
	return true;
}