## System of Iris Recognition

[简体中文](README.md) | English

#### Introduction
A sample system of iris recognition.