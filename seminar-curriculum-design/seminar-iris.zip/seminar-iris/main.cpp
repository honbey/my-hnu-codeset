/******************************************************************************************
 * Project Name: seminar-iris
 * 
 * Honbey, honbey@honbey.com
 * Created On 2020-04-08
 * Copyright (c) 2020. All rights reserved.
 * 
 * Date: 2020-05-09
 * Version: 0.0.2
 * 
 * Change Log: 一些小修改
 * 
 * Description: 《高年级研讨课》工程一
 * 
 *  
 * History: 
 * <author> <time> <version> <desc>
 * Honbey 2020-04-08 0.0.1 can display
 ******************************************************************************************/

#include "iris-ml.h"

/**
 * 主函数
 *
 * @param const char[] 可执行程序名 
 * @param const char[] 图像路径
 * @param const char[] 二值化阈值1
 * @param const char[] 二值化阈值1
 * @param const char[] 虹膜最大半径
 * @return int		   主函数返回值，值为0标识程序正常结束
 */
int main(int argc, char const *argv[]) {
	if (argc == 1) { // parameter error
		std::cout << "Parameter error!\nUsage: ./Testing <Image Path>" << std::endl;
		return -1;
	}

	std::shared_ptr<MultipleImageWindow> miw;
	IM test;

	if (argv[2]) {
		cv::Mat img = cv::imread(argv[1]); // read a image
		if (!img.data) { // image is empty or can't open it
			std::cout << "error: No image data" << std::endl;
			return -2;
		}
		miw = std::make_shared<MultipleImageWindow>("Main window", 3, 1, cv::WINDOW_AUTOSIZE);
		miw->addImage("Original Image", img);
		cv::Mat pupilImg = test.getPupil(img, 1);
		cv::Mat irisImg = test.getIris(pupilImg, 1);
		miw->addImage("Pupil", pupilImg);
		miw->addImage("Iris", irisImg);
		miw->render();
	} else {
		std::string folder = argv[1];

		cv::VideoCapture cap;

		if (!cap.open(folder)) {
			std::cout << "Can't open the folder images" << std::endl;
			return false;
		}
		miw = std::make_shared<MultipleImageWindow>("Main window", 2, 6, cv::WINDOW_AUTOSIZE);

		// 定义帧图像
		cv::Mat frame;
		int imgIndex = 1;
		for (; cap.read(frame); imgIndex++) {
			std::string tmp = std::to_string(imgIndex);
			miw->addImage("Original Image " + tmp, frame);
			// 统一图像大小
			cv::resize(frame, frame, cv::Size(300, 300));
			cv::Mat grayImg;
			frame.copyTo(grayImg);

			// 灰度化
			cv::cvtColor(grayImg, grayImg, cv::COLOR_RGB2GRAY);
			
			// LBPF编码
			grayImg = test.getLBPFeature(grayImg);
			// 提取LBP特征向量
			cv::Mat features = test.getLBPH(grayImg, 1);

			cv::Mat trainingDataMat;
			trainingDataMat.push_back(features);

			int label = static_cast<int>(test.svm->predict(trainingDataMat));

			std::stringstream ss;
			switch(label) {
				case 33:
					ss << "33"; break;
				case 48:
					ss << "48"; break;
				case 77:
					ss << "77"; break;
				case 78:
					ss << "78"; break;
				case 91:
					ss << "91"; break;
				case 98:
					ss << "98"; break;
				default:
					ss << "--";
			}

			cv::putText(grayImg, ss.str(), 
				cv::Point2d(20, 50),
				cv::FONT_HERSHEY_SIMPLEX, 2, cv::Scalar::all(255));
			miw->addImage("Result " + tmp, grayImg);
		}
		miw->render();
	}

	cv::waitKey(0);
	cv::destroyAllWindows();

	return 0;
}